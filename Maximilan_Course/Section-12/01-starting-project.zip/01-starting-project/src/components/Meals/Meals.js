import { Fragment } from 'react';

import MealItem from './MealItem/MealItem';
import MealsSummary from './MealsSummary';
import AvailableMeals from './AvailableMeals';

const Meals = () => {
  return (
    <Fragment>
      <MealsSummary />
      <AvailableMeals />
      <MealItem />
    </Fragment>
  );
};

export default Meals;